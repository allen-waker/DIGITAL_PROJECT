
from operator import mod
from django.db import models


# Create your models here.
class User(models.Model):
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=20)
    role = models.CharField(max_length=30)
    is_active = models.BooleanField(default=False)
    is_verify = models.BooleanField(default=False)
    create_at = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.email

class Chairman(models.Model):
    user_id = models.ForeignKey(User,on_delete = models.CASCADE)
    firstname = models.CharField(max_length=30)
    lastname = models.CharField(max_length=30)
    contact = models.CharField(max_length=30)
    gender = models.CharField(max_length=15)
    house_no = models.CharField(max_length=10)
    occupation = models.CharField(max_length=40)
    visiting_time = models.CharField(max_length=20)  #10AM - 12AM
    pic = models.FileField(upload_to='media/images/',default ='media/default.jpg')


    def __str__(self) -> str:
        return self.firstname + " " +self.lastname
    
class Member(models.Model):
    user_id = models.ForeignKey(User,on_delete = models.CASCADE)
    firstname = models.CharField(max_length=30)
    lastname = models.CharField(max_length=30)
    contact = models.CharField(max_length=30)
    gender = models.CharField(max_length=15)
    house_no = models.CharField(max_length=10,blank=True,null=True)
    occupation = models.CharField(max_length=40,blank=True,null=True)
    working_place = models.CharField(max_length=40,blank=True,null=True)
    family_member = models.CharField(max_length=10,blank=True,null=True)
    vehical_details = models.CharField(max_length=30,blank=True,null=True)
    blood_group = models.CharField(max_length=6,blank=True,null=True)
    birthdate = models.DateField(blank=True,null=True)
    pic = models.FileField(upload_to='media/images/',default ='media/default.jpg')

    def __str__(self) -> str:
        return self.firstname + " " +self.lastname

class Notice(models.Model):
    user_id = models.ForeignKey(User,on_delete = models.CASCADE)
    title = models.CharField(max_length=30)
    description = models.TextField(max_length = 500)
    pic = models.FileField(upload_to='media/images/',default ='media/default.jpg')
    create_at = models.DateField(auto_now_add=True)
    n_view_count = models.IntegerField(default=0)

    def __str__(self) -> str:
        return self.title

class view_notice(models.Model):
    n_id = models.ForeignKey(Notice,on_delete=models.CASCADE,blank=True,null=True)
    u_id = models.ForeignKey(User,on_delete=models.CASCADE,blank=True,null=True)
    n_date = models.DateField(auto_now_add = True)


class Event(models.Model):
    user_id = models.ForeignKey(User,on_delete=models.CASCADE)
    title = models.CharField(max_length=50)
    description = models.TextField(max_length=50)
    date_event = models.DateField(blank=True,null=True)
    event_time = models.CharField(max_length=50,blank=True,null=True)
    pic = models.FileField(upload_to="media/imegs/",blank=True,null=True)
    video = models.FileField(upload_to="media/video/",blank=True,null=True)

    def __str__(self) -> str:
        return self.title







    
    


    
